#-------------- Telegram Push Notification Bot--------------------#
#SE LATAM - Carlos Alcocer
#Sales Engineering

Param (
	[Parameter(Mandatory=$true)][string]$BotToken,
    [Parameter(Mandatory=$true)][string]$ChatID,
    [Parameter(Mandatory=$true)][string]$User,
	[String]$Host_Impacted,
	[String]$Classification,
	[String]$AlarmID,
	[String]$Date,
	[String]$AlarmName
	
)

#--------------- TLS 1.2 Forced ------------------------------#

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@

[System.net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

#-------------- Concat Strings Messages--------------------#

$string0 = "----- LogRhythm Push Notification -----"
$string1 = "1. Alarm ID: "
$string2 = "2. Date: "
$string3 = "3. User: "
$string4 = "4. Host: "
$string6 = "6. Classification: "
$string7 = "7. Alarm Name: "
$string00 = "-------------------------------------------------------------"
$command = $string0 , $string1,$AlarmID , $string2,$Date ,$string3,$User , $string4,$Host_Impacted , $string6,$Classification , $string7,$AlarmName , $string00 -join "`n"

#------------- Request API Telegram -------------------------#

function Telegram{
	
$Result = Invoke-RestMethod -Uri "https://api.telegram.org/bot$($BotToken)/sendMessage?chat_id=$($ChatID)&text=$($command)"

Write-host "Smart Response Executed - Done!  -- "$Result
}
Telegram

 